# Il Mio Gin + Il Mio Vino © Bibirub

Questo è il **progetto sorgente Android**, non un APK già compilato. Include le due collezioni fotografate e un contenitore WebView con origine HTTPS locale: non richiede Netlify né un server per funzionare. Fotocamera, selezione dalla galleria e GPS sono gestiti dal dispositivo Android.

## Copyright
© 2026 Bibirub · Tutti i diritti riservati, nella schermata di scelta, nelle app e nelle sezioni Informazioni.

## Generare il file APK

### Opzione A — GitHub Actions (senza PC, dal browser se riesci a caricare il progetto su GitHub)
1. Crea un repository GitHub vuoto. Carica **il contenuto della cartella del progetto** (inclusa `.github/workflows/build-apk.yml`) sulla branch `main`.
2. Apri la scheda **Actions** → **Build APK Bibirub** → **Run workflow**.
3. Al termine, apri il workflow riuscito e scarica l'artifact `Il_Mio_Gin_Vino_Bibirub`; contiene `Il_Mio_Gin_Vino_Bibirub.apk`.
4. Apri l'APK sul telefono Android e autorizza l'installazione di app da quella fonte se Android te lo chiede.

L'artifact debug è firmato automaticamente con chiave di debug dal runner e pensato per test personali, non per pubblicazione sul Play Store. Non usare GitHub pubblico per inserire contenuti privati.

### Opzione B — Android Studio / Gradle
Richiede JDK 17, Android SDK Platform 35 e Gradle 8.7. Apri questa cartella in Android Studio con un'installazione Gradle 8.7 o dal terminale esegui `gradle assembleDebug`. APK risultante: `app/build/outputs/apk/debug/app-debug.apk`.

## Note
- Funziona su **Android 8 (API 26) e successivi**. Non funziona su iPhone.
- I dati di Gin e Vino vengono salvati in IndexedDB separati nella WebView dell'app e **non** vengono sincronizzati con l'app HTML precedentemente aperta in Safari/Chrome. Importa un backup se devi spostare i dati.
- GPS disponibile solo con permesso concesso. La posizione di foto caricate in seguito non coincide necessariamente con quella originale.
- Richiede una compilazione Android: da questo ambiente non è possibile produrre o testare l'APK perché non sono presenti Android SDK, Gradle e i download sono bloccati.
